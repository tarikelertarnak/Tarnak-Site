import { DragDropProvider } from "@dnd-kit/react";
import { useAppStore, useAppStoreApi } from "../../store";
import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { AutoScroller, defaultPreset, DragDropManager } from "@dnd-kit/dom";
import { DragDropEventHandlers } from "@dnd-kit/abstract";
import { DropZoneProvider } from "../DropZone";
import type { Draggable, Droppable } from "@dnd-kit/dom";
import { getItem } from "../../lib/data/get-item";
import {
  DropZoneContext,
  Preview,
  RootVirtualizerHandle,
  ZoneStore,
  ZoneStoreProvider,
} from "../DropZone/context";
import { createNestedDroppablePlugin } from "../../lib/dnd/NestedDroppablePlugin";
import { prepareCommitFlip } from "../../lib/dnd/flip-commit";
import { resolveDndMode } from "../../lib/dnd/resolve-dnd-mode";
import { getZoneContentIds } from "../../lib/get-zone-content-ids";
import { getComponentSelector } from "../../lib/dom-selectors";
import { insertComponent } from "../../lib/insert-component";
import { moveComponent } from "../../lib/move-component";
import { useDebouncedCallback } from "use-debounce";
import { ComponentDndData } from "../DraggableComponent";

import { collisionStore } from "../../lib/dnd/collision/dynamic/store";
import { generateId } from "../../lib/generate-id";
import { createStore } from "zustand";
import { getDeepDir } from "../../lib/get-deep-dir";
import {
  getCollisionPosition,
  getInsertIndex,
} from "../../lib/dnd/get-insert-index";
import { useSensors } from "../../lib/dnd/use-sensors";
import { getFrame } from "../../lib/get-frame";
import { effect } from "@dnd-kit/state";
import type { DndBehavior } from "../../types";
import { useLinePlaceholder } from "./use-line-placeholder";

const DEBUG = false;

type Events = DragDropEventHandlers<Draggable, Droppable, DragDropManager>;
type DragCbs = Partial<{ [eventName in keyof Events]: Events[eventName][] }>;

const dragListenerContext = createContext<{
  dragListeners: DragCbs;
  setDragListeners?: Dispatch<SetStateAction<DragCbs>>;
}>({
  dragListeners: {},
});

type EventKeys = keyof Events & string;

export function useDragListener(
  type: EventKeys,
  fn: Events[EventKeys],
  deps: any[] = []
) {
  const { setDragListeners } = useContext(dragListenerContext);

  useEffect(() => {
    if (setDragListeners) {
      setDragListeners((old) => ({
        ...old,
        [type]: [...(old[type] || []), fn],
      }));
    }
  }, deps);
}

type DeepestParams = {
  zone: string | null;
  area: string | null;
};

const AREA_CHANGE_DEBOUNCE_MS = 100;

type DragDropContextProps = {
  children: ReactNode;
  disableAutoScroll?: boolean;
  behavior?: DndBehavior;
};

/**
 * Temporarily disable fallback collisions types, which
 * can cause issues during a zone switch.
 *
 * @param timeout the time in ms to disable the fallback collision for
 * @returns a function that temporarily disables the collision
 */
const useTempDisableFallback = (timeout: number) => {
  const lastFallbackDisable = useRef<string>(null);

  return useCallback((manager: DragDropManager) => {
    collisionStore.setState({ fallbackEnabled: false });

    // Track an ID in case called more than once, so only last call re-enables
    const fallbackId = generateId();
    lastFallbackDisable.current = fallbackId;

    setTimeout(() => {
      if (lastFallbackDisable.current === fallbackId) {
        collisionStore.setState({ fallbackEnabled: true });
        manager.collisionObserver.forceUpdate(true);
      }
    }, timeout);
  }, []);
};

const DragDropContextClient = ({
  children,
  disableAutoScroll,
  behavior = "auto",
}: DragDropContextProps) => {
  const dispatch = useAppStore((s) => s.dispatch);
  const instanceId = useAppStore((s) => s.instanceId);
  const appStore = useAppStoreApi();

  const debouncedParamsRef = useRef<DeepestParams | null>(null);

  const tempDisableFallback = useTempDisableFallback(100);

  const [zoneStore] = useState(() => {
    const rootVirtualizers = new Map<string, RootVirtualizerHandle>();

    return createStore<ZoneStore>(() => ({
      zoneDepthIndex: {},
      nextZoneDepthIndex: {},
      areaDepthIndex: {},
      nextAreaDepthIndex: {},
      draggedItem: null,
      previewIndex: {},
      enabledIndex: {},
      hoveringComponent: null,
      registerRootVirtualizer: (zoneCompound, handle) => {
        rootVirtualizers.set(zoneCompound, handle);
      },
      unregisterRootVirtualizer: (zoneCompound) => {
        rootVirtualizers.delete(zoneCompound);
      },
      scrollToComponent: (id) => {
        const virtualizers = Array.from(rootVirtualizers.values());

        if (virtualizers.length > 0) {
          for (const handle of virtualizers) {
            const index = handle.resolveIndex(id);

            if (index < 0) {
              continue;
            }

            handle.virtualizer.scrollToIndex(index, {
              behavior: "auto", // We avoid smooth scroll as this triggers virtualizer renders
              align: "auto",
            });
          }
        } else {
          const frame = getFrame();
          const el = frame?.querySelector(getComponentSelector(id));
          el?.scrollIntoView({ behavior: "smooth" });
        }
      },
    }));
  });

  const getChanged = useCallback(
    (params: DeepestParams) => {
      const { zoneDepthIndex = {}, areaDepthIndex = {} } =
        zoneStore.getState() || {};

      const stateHasZone = Object.keys(zoneDepthIndex).length > 0;
      const stateHasArea = Object.keys(areaDepthIndex).length > 0;

      let zoneChanged = false;
      let areaChanged = false;

      if (params.zone && !zoneDepthIndex[params.zone]) {
        zoneChanged = true;
      } else if (!params.zone && stateHasZone) {
        zoneChanged = true;
      }

      if (params.area && !areaDepthIndex[params.area]) {
        areaChanged = true;
      } else if (!params.area && stateHasArea) {
        areaChanged = true;
      }

      return { zoneChanged, areaChanged };
    },
    [zoneStore]
  );

  const setDeepestAndCollide = useCallback(
    (params: DeepestParams, manager: DragDropManager) => {
      const { zoneChanged, areaChanged } = getChanged(params);

      if (!zoneChanged && !areaChanged) return;

      zoneStore.setState({
        zoneDepthIndex: params.zone ? { [params.zone]: true } : {},
        areaDepthIndex: params.area ? { [params.area]: true } : {},
      });

      // Disable fallback collisions temporarily after zone change,
      // as these can cause unexpected collisions
      tempDisableFallback(manager);

      setTimeout(() => {
        // Force update after debounce
        manager.collisionObserver.forceUpdate(true);
      }, 50);

      debouncedParamsRef.current = null;
    },
    [zoneStore]
  );

  const setDeepestDb = useDebouncedCallback(
    setDeepestAndCollide,
    AREA_CHANGE_DEBOUNCE_MS
  );

  const cancelDb = () => {
    setDeepestDb.cancel();
    debouncedParamsRef.current = null;
  };

  useEffect(() => {
    if (DEBUG) {
      zoneStore.subscribe((s) =>
        console.log(
          s.previewIndex,
          Object.entries(s.zoneDepthIndex || {})[0]?.[0],
          Object.entries(s.areaDepthIndex || {})[0]?.[0]
        )
      );
    }
  }, []);

  const [plugins] = useState(() => [
    ...(disableAutoScroll
      ? defaultPreset.plugins.filter((plugin) => plugin !== AutoScroller)
      : defaultPreset.plugins),
    createNestedDroppablePlugin(
      {
        onChange: (params, manager) => {
          const state = zoneStore.getState();

          const { zoneChanged, areaChanged } = getChanged(params);

          const isDragging = manager.dragOperation.status.dragging;

          if (areaChanged || zoneChanged) {
            let nextZoneDepthIndex: Record<string, boolean> = {};
            let nextAreaDepthIndex: Record<string, boolean> = {};

            if (params.zone) {
              nextZoneDepthIndex = { [params.zone]: true };
            }

            if (params.area) {
              nextAreaDepthIndex = { [params.area]: true };
            }

            zoneStore.setState({ nextZoneDepthIndex, nextAreaDepthIndex });
          }

          if (params.zone !== "void" && state?.zoneDepthIndex["void"]) {
            setDeepestAndCollide(params, manager);
            return;
          }

          if (areaChanged) {
            if (isDragging) {
              // Only call the debounced function if these params differ from the last pending call
              const debouncedParams = debouncedParamsRef.current;
              const isSameParams =
                debouncedParams &&
                debouncedParams.area === params.area &&
                debouncedParams.zone === params.zone;

              if (!isSameParams) {
                cancelDb(); // NB we always cancel the debounce if the params change, so we could just use a timer
                setDeepestDb(params, manager);
                debouncedParamsRef.current = params;
              }
            } else {
              cancelDb();
              setDeepestAndCollide(params, manager);
            }

            return;
          }

          if (zoneChanged) {
            setDeepestAndCollide(params, manager);
          }

          cancelDb();
        },
      },
      instanceId
    ),
  ]);

  const sensors = useSensors();

  const [dragListeners, setDragListeners] = useState<DragCbs>({});

  const dragMode = useRef<"new" | "existing" | null>(null);

  const initialSelector = useRef<{ zone: string; index: number }>(undefined);

  const {
    getTargetIndex: getLinePlaceholderTargetIndex,
    setActive: setLinePlaceholderActive,
    startScrollTracking: startLinePlaceholderScrollTracking,
    stopScrollTracking: stopLinePlaceholderScrollTracking,
    update: updateLinePlaceholder,
  } = useLinePlaceholder(zoneStore);

  const nextContextValue = useMemo<DropZoneContext>(
    () => ({
      mode: "edit",
      areaId: "root",
      depth: 0,
    }),
    []
  );

  return (
    <dragListenerContext.Provider
      value={{
        dragListeners,
        setDragListeners,
      }}
    >
      <DragDropProvider
        plugins={plugins}
        sensors={sensors}
        onDragEnd={(event, manager) => {
          stopLinePlaceholderScrollTracking();

          const entryEl = getFrame()?.querySelector("[data-puck-entry]");
          entryEl?.removeAttribute("data-puck-dragging");

          const { source, target } = event.operation;

          if (!source) {
            setLinePlaceholderActive(false);
            zoneStore.setState({ draggedItem: null });

            return;
          }

          const { zone, index } = source.data as ComponentDndData;

          const { previewIndex = {} } = zoneStore.getState() || {};

          // Look the preview up by id: during line placeholder (cross-zone)
          // drags the source stays in its original zone, so the preview key
          // no longer matches the source's zone. Ghost previews only pin the
          // item visually and never describe the drop position.
          const thisPreview: Preview | null =
            Object.values(previewIndex).find(
              (preview) => preview?.props.id === source.id && !preview.ghost
            ) ?? null;

          // Capture sibling positions now, before dnd-kit tears the drag
          // state down, so the slide animations measure from what's on
          // screen at the moment of drop
          const playCommitFlip =
            !event.canceled &&
            target?.type !== "void" &&
            thisPreview?.linePlaceholder
              ? prepareCommitFlip({
                  zones: initialSelector.current
                    ? [initialSelector.current.zone, thisPreview.zone]
                    : [thisPreview.zone],
                  itemId:
                    thisPreview.type === "move"
                      ? thisPreview.props.id
                      : undefined,
                  targetZone: thisPreview.zone,
                  getExpectedOrder: () =>
                    getZoneContentIds(
                      appStore.getState().state,
                      thisPreview.zone
                    ),
                })
              : null;

          const onAnimationEnd = () => {
            // Keep the ghost faded until the drop animation lands
            setLinePlaceholderActive(false);
            zoneStore.setState({ draggedItem: null });

            // Tidy up cancellation
            if (event.canceled || target?.type === "void") {
              zoneStore.setState({ previewIndex: {} });

              dragListeners.dragend?.forEach((fn) => {
                fn(event, manager);
              });

              dispatch({
                type: "setUi",
                ui: {
                  itemSelector: null,
                  isDragging: false,
                },
              });

              return;
            }

            // Line placeholder indices count the dragged item at its
            // original position, so moving to a later gap within the same
            // zone lands one index lower once the item is removed
            const commitIndex =
              thisPreview &&
              thisPreview.linePlaceholder &&
              initialSelector.current &&
              thisPreview.zone === initialSelector.current.zone &&
              thisPreview.index > initialSelector.current.index
                ? thisPreview.index - 1
                : thisPreview?.index ?? index;

            // Finalise the drag
            if (thisPreview) {
              zoneStore.setState({ previewIndex: {} });

              if (thisPreview.type === "insert") {
                insertComponent(
                  thisPreview.componentType,
                  thisPreview.zone,
                  thisPreview.index,
                  appStore
                );
              } else if (initialSelector.current) {
                moveComponent(
                  thisPreview.props.id,
                  initialSelector.current,
                  { ...thisPreview, index: commitIndex },
                  appStore
                );
              }

              playCommitFlip?.();
            }

            const movedToNewPosition =
              initialSelector.current?.zone !== thisPreview?.zone ||
              initialSelector.current?.index !== commitIndex;

            dispatch({
              type: "setUi",
              ui: {
                itemSelector: thisPreview
                  ? { index: commitIndex, zone: thisPreview.zone }
                  : { index, zone },
                isDragging: false,
              },
              recordHistory: movedToNewPosition,
            });

            dragListeners.dragend?.forEach((fn) => {
              fn(event, manager);
            });
          };

          // Delay insert until animation has finished
          let dispose: () => void | undefined;

          dispose = effect(() => {
            if (source.status === "idle") {
              onAnimationEnd();
              dispose?.();
            }
          });
        }}
        onDragMove={(event, manager) => {
          // Keep the line in the gap nearest the pointer as it moves within
          // the target zone: collisions only re-fire when the target
          // changes, which can leave the line in a stale gap
          updateLinePlaceholder(manager);

          dragListeners.dragmove?.forEach((fn) => {
            fn(event, manager);
          });
        }}
        onDragOver={(event, manager) => {
          // Prevent the optimistic re-ordering
          event.preventDefault();

          const draggedItem = zoneStore.getState()?.draggedItem;

          // Drag end can sometimes trigger after drag
          if (!draggedItem) return;

          // Cancel any stale debounces
          cancelDb();

          const { source, target } = event.operation;

          if (!target || !source || target.type === "void") return;

          const [sourceId] = (source.id as string).split(":");
          const [targetId] = (target.id as string).split(":");

          const sourceData = source.data as ComponentDndData;

          let sourceZone = sourceData.zone;
          let sourceIndex = sourceData.index;

          let targetZone = "";
          let targetIndex = 0;

          if (target.type === "component") {
            const targetData = target.data as ComponentDndData;

            targetZone = targetData.zone;

            const collisionData = manager.collisionObserver.collisions[0]?.data;

            const position = getCollisionPosition(
              collisionData?.direction,
              getDeepDir(target.element)
            );

            targetIndex = getInsertIndex({
              position,
              sourceIndex,
              targetIndex: targetData.index,
              isSameZone: sourceZone === targetZone,
            });
          } else {
            targetZone = target.id.toString();
            targetIndex = 0;
          }

          const path =
            appStore.getState().state.indexes.nodes[target.id]?.path || [];

          // Abort if dragging over self or descendant
          if (
            targetId === sourceId ||
            path.find((path) => {
              const [pathId] = (path as string).split(":");
              return pathId === sourceId;
            })
          ) {
            return;
          }

          if (dragMode.current === "new") {
            const isLinePlaceholder =
              resolveDndMode(behavior, { isNewComponent: true }) === "static";

            if (isLinePlaceholder) {
              targetIndex =
                getLinePlaceholderTargetIndex(targetZone, manager) ??
                targetIndex;
            }

            setLinePlaceholderActive(isLinePlaceholder);

            zoneStore.setState({
              previewIndex: {
                [targetZone]: {
                  componentType: sourceData.componentType,
                  type: "insert",
                  index: targetIndex,
                  zone: targetZone,
                  element: source.element,
                  props: {
                    id: source.id.toString(),
                  },
                  linePlaceholder: isLinePlaceholder,
                },
              },
            });
          } else {
            if (!initialSelector.current) {
              initialSelector.current = {
                zone: sourceData.zone,
                index: sourceData.index,
              };
            }

            const item = getItem(
              initialSelector.current,
              appStore.getState().state
            );

            if (item) {
              const originZone = initialSelector.current.zone;
              const isReparenting = originZone !== targetZone;
              const isLinePlaceholder =
                resolveDndMode(behavior, {
                  isDraggingBetweenSlots: isReparenting,
                }) === "static";

              if (isLinePlaceholder) {
                targetIndex =
                  getLinePlaceholderTargetIndex(targetZone, manager) ??
                  targetIndex;
              }

              setLinePlaceholderActive(isLinePlaceholder);

              const previewIndex: Record<string, Preview> = {
                [targetZone]: {
                  componentType: sourceData.componentType,
                  type: "move",
                  index: targetIndex,
                  zone: targetZone,
                  props: item.props,
                  element: source.element,
                  linePlaceholder: isLinePlaceholder,
                },
              };

              // If line, pin the item as a ghost at its currently rendered position in the original zone.
              if (isLinePlaceholder && isReparenting) {
                const originPreview =
                  zoneStore.getState().previewIndex[originZone];

                // Assume we were in static mode. Preview didn't move the item.
                let originIndex = initialSelector.current.index;

                // Current preview isn't line placeholder. We were in fluid mode.
                // Preview moved the item to its latest index. Pin the ghost preview there.
                if (originPreview && !originPreview.linePlaceholder) {
                  originIndex = originPreview.index;
                }

                previewIndex[originZone] = {
                  componentType: sourceData.componentType,
                  type: "move",
                  index: originIndex,
                  zone: originZone,
                  props: item.props,
                  element: source.element,
                  ghost: true,
                };
              }

              zoneStore.setState({ previewIndex });
            }
          }

          dragListeners.dragover?.forEach((fn) => {
            fn(event, manager);
          });
        }}
        onDragStart={(event, manager) => {
          if (behavior !== "fluid") {
            // Scrolling moves the content under a stationary pointer without
            // firing drag events, which would leave the line placeholder
            // drifting with the page; recompute it on scroll.
            startLinePlaceholderScrollTracking(manager);
          }

          const { source } = event.operation;

          if (source?.type === "component") {
            const sourceData = source.data as ComponentDndData;
            const sourceSelector = {
              zone: sourceData.zone,
              index: sourceData.index,
            };

            initialSelector.current = sourceSelector;

            const item = getItem(sourceSelector, appStore.getState().state);

            if (item) {
              const showLinePlaceholder = resolveDndMode(behavior) === "static";

              setLinePlaceholderActive(showLinePlaceholder);

              zoneStore.setState({
                previewIndex: {
                  [sourceData.zone]: {
                    componentType: sourceData.componentType,
                    type: "move",
                    index: sourceData.index,
                    zone: sourceData.zone,
                    props: item.props,
                    element: source.element,
                    linePlaceholder: showLinePlaceholder,
                  },
                },
              });
            }
          }

          dragListeners.dragstart?.forEach((fn) => {
            fn(event, manager);
          });
        }}
        onBeforeDragStart={(event) => {
          const isNewComponent = event.operation.source?.type === "drawer";

          dragMode.current = isNewComponent ? "new" : "existing";
          initialSelector.current = undefined;

          zoneStore.setState({ draggedItem: event.operation.source });

          if (
            appStore.getState().selectedItem?.props.id !==
            event.operation.source?.id
          ) {
            dispatch({
              type: "setUi",
              ui: {
                itemSelector: null,
                isDragging: true,
              },
              recordHistory: false,
            });
          } else {
            dispatch({
              type: "setUi",
              ui: {
                isDragging: true,
              },
              recordHistory: false,
            });
          }

          const entryEl = getFrame()?.querySelector("[data-puck-entry]");
          entryEl?.setAttribute("data-puck-dragging", "true");
          setLinePlaceholderActive(false);
        }}
      >
        <ZoneStoreProvider store={zoneStore}>
          <DropZoneProvider value={nextContextValue}>
            {children}
          </DropZoneProvider>
        </ZoneStoreProvider>
      </DragDropProvider>
    </dragListenerContext.Provider>
  );
};

export const DragDropContext = ({
  children,
  disableAutoScroll,
  behavior,
}: DragDropContextProps) => {
  const status = useAppStore((s) => s.status);

  if (status === "LOADING") {
    return children;
  }

  return (
    <DragDropContextClient
      disableAutoScroll={disableAutoScroll}
      behavior={behavior}
    >
      {children}
    </DragDropContextClient>
  );
};
