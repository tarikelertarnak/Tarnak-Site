import {
  CSSProperties,
  ReactNode,
  Ref,
  SyntheticEvent,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";
import styles from "./styles.module.css";
import "./styles.css";
import getClassNameFactory from "../../lib/get-class-name-factory";
import { Copy, CornerLeftUp, Trash } from "lucide-react";
import { useAppStore, useAppStoreApi } from "../../store";
import { Loader } from "../Loader";
import { ActionBar } from "../ActionBar";

import { createPortal } from "react-dom";

import { dropZoneContext, DropZoneProvider } from "../DropZone";
import { createDynamicCollisionDetector } from "../../lib/dnd/collision/dynamic";
import { DragAxis } from "../../types";
import { UniqueIdentifier } from "@dnd-kit/abstract";
import { Feedback } from "@dnd-kit/dom";
import { getDeepScrollPosition } from "../../lib/get-deep-scroll-position";
import { DropZoneContext, ZoneStoreContext } from "../DropZone/context";
import { useShallow } from "zustand/react/shallow";
import { getItem } from "../../lib/data/get-item";
import { useSortable } from "@dnd-kit/react/sortable";
import { useContextStore } from "../../lib/use-context-store";
import { useOnDragFinished } from "../../lib/dnd/use-on-drag-finished";
import { useDropAnimation } from "../DragDropContext/use-drop-animation";
import { LoadedRichTextMenu } from "../RichTextMenu";
import type { NodeHandle } from "../../store/slices/nodes";
import { assignRefs } from "../../lib/assign-refs";
import { useMessage } from "../../lib/use-message";

const getClassName = getClassNameFactory("DraggableComponent", styles);

const DEBUG = false;
const MEASURE_EVERY_MS = 100; // 10fps

// Magic numbers are used to position actions overlay 8px from top of component, bottom of component (when sticky scrolling) and side of preview
const space = 8;
const actionsOverlayTop = space * 6.5;
const actionsTop = -(actionsOverlayTop - 8);
const actionsSide = space;

const DefaultActionBar = ({
  label,
  children,
  parentAction,
}: {
  label: string | undefined;
  children: ReactNode;
  parentAction: ReactNode;
}) => (
  <ActionBar>
    <ActionBar.Group>
      {parentAction}
      {label && <ActionBar.Label label={label} />}
    </ActionBar.Group>
    <ActionBar.Group>{children}</ActionBar.Group>
  </ActionBar>
);

const DefaultOverlay = ({
  children,
}: {
  children: ReactNode;
  hover: boolean;
  isSelected: boolean;
  componentId: string;
  componentType: string;
}) => <>{children}</>;

export type ComponentDndData = {
  areaId?: string;
  zone: string;
  index: number;
  componentType: string;
  containsActiveZone: boolean;
  depth: number;
  path: UniqueIdentifier[];
  inDroppableZone: boolean;
};

export const DraggableComponent = ({
  children,
  depth,
  componentType,
  id,
  index,
  zoneCompound,
  isLoading = false,
  isSelected = false,
  debug,
  label,
  autoDragAxis,
  userDragAxis,
  inDroppableZone = true,
  itemRef,
}: {
  children: (ref: Ref<any>) => ReactNode;
  componentType: string;
  depth: number;
  id: string;
  index: number;
  zoneCompound: string;
  isSelected?: boolean;
  debug?: string;
  label?: string;
  isLoading: boolean;
  autoDragAxis: DragAxis;
  userDragAxis?: DragAxis;
  inDroppableZone: boolean;
  itemRef?: Ref<HTMLElement>;
}) => {
  const zoom = useAppStore((s) =>
    s.selectedItem?.props.id === id ? s.zoomConfig.zoom : 1
  );
  const _experimentalFullScreenCanvas = useAppStore(
    (s) => s._experimentalFullScreenCanvas
  );
  const overrides = useAppStore((s) => s.overrides);
  const dispatch = useAppStore((s) => s.dispatch);
  const iframe = useAppStore((s) => s.iframe);
  const lastMeasureRef = useRef(0);

  const ctx = useContext(dropZoneContext);

  const [localZones, setLocalZones] = useState<Record<string, boolean>>({});

  const registerLocalZone = useCallback(
    (zoneCompound: string, active: boolean) => {
      // Propagate local zone
      ctx?.registerLocalZone?.(zoneCompound, active);

      setLocalZones((obj) => ({
        ...obj,
        [zoneCompound]: active,
      }));
    },
    [setLocalZones]
  );

  const unregisterLocalZone = useCallback(
    (zoneCompound: string) => {
      // Propagate local zone
      ctx?.unregisterLocalZone?.(zoneCompound);

      setLocalZones((obj) => {
        const newLocalZones = {
          ...obj,
        };

        delete newLocalZones[zoneCompound];

        return newLocalZones;
      });
    },
    [setLocalZones]
  );

  const containsActiveZone =
    Object.values(localZones).filter(Boolean).length > 0;

  const path = useAppStore(useShallow((s) => s.state.indexes.nodes[id]?.path));
  const permissions = useAppStore(
    useShallow((s) => {
      const item = getItem({ index, zone: zoneCompound }, s.state);

      return s.permissions.getPermissions({ item });
    })
  );

  const zoneStore = useContext(ZoneStoreContext);
  const appStore = useAppStoreApi();

  const [dragAxis, setDragAxis] = useState(userDragAxis || autoDragAxis);

  const dynamicCollisionDetector = useMemo(
    () => createDynamicCollisionDetector(dragAxis),
    [dragAxis]
  );

  // The default drop animation targets the source placeholder. Line drags and
  // drawer insertion previews instead commit immediately and glide a visual
  // copy to the item's final rendered position.
  const dropAnimation = useDropAnimation(zoneStore, id);

  const {
    ref: sortableRef,
    isDragging: thisIsDragging,
    sortable,
  } = useSortable<ComponentDndData>({
    id,
    index,
    group: zoneCompound,
    type: "component",
    data: {
      areaId: ctx?.areaId,
      zone: zoneCompound,
      index,
      componentType,
      containsActiveZone,
      depth,
      path: path || [],
      inDroppableZone,
    },
    collisionPriority: depth,
    collisionDetector: dynamicCollisionDetector,
    // "Out of the way" transition from react-beautiful-dnd
    transition: {
      duration: 200,
      easing: "cubic-bezier(0.2, 0, 0, 1)",
    },
    plugins: (defaults) => [
      ...defaults,
      Feedback.configure({ feedback: "clone", dropAnimation }),
    ],
  });

  useEffect(() => {
    const isEnabled = zoneStore.getState().enabledIndex[zoneCompound];

    sortable.droppable.disabled = !isEnabled;
    sortable.draggable.disabled = !permissions.drag;

    const cleanup = zoneStore.subscribe((s) => {
      sortable.droppable.disabled = !s.enabledIndex[zoneCompound];
    });

    if (ref.current && !permissions.drag) {
      ref.current.setAttribute("data-puck-disabled", "");

      return () => {
        ref.current?.removeAttribute("data-puck-disabled");
        cleanup();
      };
    }

    return cleanup;
  }, [permissions.drag, zoneCompound]);

  const [, setRerender] = useState(0);

  const ref = useRef<HTMLElement>(null);

  const refSetter = useCallback(
    (el: HTMLElement | null) => {
      sortableRef(el);

      if (ref.current !== el) {
        ref.current = el;
        setRerender((update) => update + 1);

        if (itemRef) {
          assignRefs([itemRef], el);
        }
      }
    },
    [itemRef, sortableRef]
  );

  const [portalEl, setPortalEl] = useState<HTMLElement>();

  useEffect(() => {
    setPortalEl(
      iframe.enabled
        ? ref.current?.ownerDocument.body
        : ref.current?.closest<HTMLElement>("[data-puck-preview]") ??
            document.body
    );
  }, [iframe.enabled]);

  const getStyle = useCallback(() => {
    if (!ref.current) return;

    const el = ref.current!;
    const rect = el.getBoundingClientRect();
    const portalContainerEl = iframe.enabled
      ? null
      : el.closest<HTMLElement>("[data-puck-preview]");

    const targetIsFixed = (() => {
      let node: HTMLElement | null = el;

      while (node && node !== document.documentElement) {
        if (getComputedStyle(node).position === "fixed") {
          return true;
        }
        node = node.parentElement;
      }

      return false;
    })();

    const portalContainerRect = portalContainerEl?.getBoundingClientRect();
    const portalScroll = portalContainerEl
      ? getDeepScrollPosition(portalContainerEl)
      : { x: 0, y: 0 };
    const deepScrollPosition = targetIsFixed
      ? { x: 0, y: 0 }
      : getDeepScrollPosition(el);

    const scroll = targetIsFixed
      ? { x: 0, y: 0 }
      : {
          x:
            deepScrollPosition.x -
            portalScroll.x -
            (portalContainerRect?.left ?? 0),
          y:
            deepScrollPosition.y -
            portalScroll.y -
            (portalContainerRect?.top ?? 0),
        };

    const style: CSSProperties = {
      left: `${rect.left + scroll.x}px`,
      top: `${rect.top + scroll.y}px`,
      height: `${rect.height}px`,
      width: `${rect.width}px`,
      position: targetIsFixed ? "fixed" : undefined,
    };

    return style;
  }, [iframe.enabled]);

  const [style, setStyle] = useState<CSSProperties>();
  const lastRectRef = useRef<DOMRectReadOnly | null>(null);

  // PERFORMANCE: coalesce multiple triggers into a single rAF'd sync
  const syncRafRef = useRef<number | null>(null);

  const sync = useCallback(() => {
    setStyle(getStyle());

    if (itemRef) {
      assignRefs([itemRef], ref.current);
    }
  }, [getStyle, itemRef]);

  const scheduleSync = useCallback(() => {
    if (syncRafRef.current != null) return;

    syncRafRef.current = requestAnimationFrame(() => {
      syncRafRef.current = null;
      sync();
    });
  }, [sync]);

  useEffect(() => {
    return () => {
      if (syncRafRef.current != null) {
        cancelAnimationFrame(syncRafRef.current);
        syncRafRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (ref.current) {
      const observer = new ResizeObserver(() => {
        scheduleSync();
      });

      observer.observe(ref.current);

      return () => {
        observer.disconnect();
      };
    }
  }, [scheduleSync, itemRef]);

  const registerNode = useAppStore((s) => s.nodes.registerNode);
  const unregisterNode = useAppStore((s) => s.nodes.unregisterNode);

  const hideOverlay = useCallback(() => {
    setIsVisible(false);
  }, []);

  const showOverlay = useCallback(() => {
    setIsVisible(true);
  }, []);

  const nodeHandleRef = useRef<NodeHandle>({
    sync: () => null,
    hideOverlay: () => null,
    showOverlay: () => null,
  });

  useLayoutEffect(() => {
    nodeHandleRef.current.sync = sync;
    nodeHandleRef.current.hideOverlay = hideOverlay;
    nodeHandleRef.current.showOverlay = showOverlay;
  }, [hideOverlay, showOverlay, sync]);

  useEffect(() => {
    registerNode(id, nodeHandleRef.current);

    return () => {
      unregisterNode(id);
    };
  }, [id, registerNode, unregisterNode]);

  const CustomActionBar = useMemo(
    () => overrides.actionBar || DefaultActionBar,
    [overrides.actionBar]
  );

  const CustomOverlay = useMemo(
    () => overrides.componentOverlay || DefaultOverlay,
    [overrides.componentOverlay]
  );

  const onClick = useCallback(
    (e: Event | SyntheticEvent) => {
      // Don't change selection during a drag.
      // This avoids mouseup clicks selecting the dragged-over component.
      const userIsDragging = !!zoneStore.getState().draggedItem;
      if (userIsDragging) {
        return;
      }

      const el = e.target as Element;

      if (!el.closest("[data-puck-overlay-portal]")) {
        e.stopPropagation();
      }

      if (_experimentalFullScreenCanvas) {
        dispatch({
          type: "setUi",
          ui: {
            itemSelector: isSelected ? null : { index, zone: zoneCompound },
          },
        });
      } else {
        dispatch({
          type: "setUi",
          ui: {
            itemSelector: { index, zone: zoneCompound },
          },
        });
      }
    },
    [index, zoneCompound, id, isSelected, _experimentalFullScreenCanvas]
  );

  const onSelectParent = useCallback(() => {
    const { nodes, zones } = appStore.getState().state.indexes;
    const node = nodes[id];

    const parentNode = node?.parentId ? nodes[node?.parentId] : null;

    if (!parentNode || !node.parentId) {
      return;
    }

    const parentZoneCompound = `${parentNode.parentId}:${parentNode.zone}`;

    const parentIndex = zones[parentZoneCompound].contentIds.indexOf(
      node.parentId
    );

    dispatch({
      type: "setUi",
      ui: {
        itemSelector: {
          zone: parentZoneCompound,
          index: parentIndex,
        },
      },
    });
  }, [ctx, path]);

  const onDuplicate = useCallback(() => {
    dispatch({
      type: "duplicate",
      sourceIndex: index,
      sourceZone: zoneCompound,
    });
  }, [index, zoneCompound]);

  const onDelete = useCallback(() => {
    dispatch({
      type: "remove",
      index: index,
      zone: zoneCompound,
    });
  }, [index, zoneCompound]);

  const [hover, setHover] = useState(false);

  const indicativeHover = useContextStore(
    ZoneStoreContext,
    (s) => s.hoveringComponent === id
  );

  useEffect(() => {
    if (!ref.current) {
      return;
    }

    const el = ref.current as HTMLElement;

    const _onMouseOver = (e: Event) => {
      const userIsDragging = !!zoneStore.getState().draggedItem;

      if (userIsDragging) {
        // User is dragging, and dragging this item
        if (thisIsDragging) {
          setHover(true);
        } else {
          setHover(false);
        }
      } else {
        setHover(true);
      }

      e.stopPropagation();
    };

    const _onMouseOut = (e: Event) => {
      e.stopPropagation();

      setHover(false);
    };

    el.setAttribute("data-puck-component", id);
    el.setAttribute("data-puck-dnd", id);
    el.style.position = "relative";
    el.addEventListener("click", onClick);
    el.addEventListener("mouseover", _onMouseOver);
    el.addEventListener("mouseout", _onMouseOut);

    return () => {
      el.removeAttribute("data-puck-component");
      el.removeAttribute("data-puck-dnd");
      el.removeEventListener("click", onClick);
      el.removeEventListener("mouseover", _onMouseOver);
      el.removeEventListener("mouseout", _onMouseOut);
    };
  }, [
    ref.current, // Remount attributes if the element changes
    onClick,
    containsActiveZone,
    zoneCompound,
    id,
    thisIsDragging,
    inDroppableZone,
  ]);

  const [isVisible, setIsVisible] = useState(false);
  const [dragFinished, setDragFinished] = useState(true);
  const [_, startTransition] = useTransition();

  useEffect(() => {
    startTransition(() => {
      if (hover || indicativeHover || isSelected) {
        scheduleSync();
        setIsVisible(true);
        setThisWasDragging(false);
      } else {
        setIsVisible(false);
      }
    });
  }, [hover, indicativeHover, isSelected, iframe]);

  const [thisWasDragging, setThisWasDragging] = useState(false);

  const onDragFinished = useOnDragFinished((finished) => {
    if (finished) {
      startTransition(() => {
        // Sync immediately, to avoid a flash of the overlay in the wrong place.
        sync();
        setDragFinished(true);
      });
    } else {
      setDragFinished(false);
    }
  });

  useEffect(() => {
    if (thisIsDragging) {
      setThisWasDragging(true);
    }
  }, [thisIsDragging]);

  useEffect(() => {
    if (thisWasDragging) return onDragFinished();
  }, [thisWasDragging, onDragFinished]);

  // PERFORMANCE: when visible, respond to scroll/resize + track layout shifts without a global rAF loop
  useEffect(() => {
    if (!dragFinished || !(isSelected || thisIsDragging)) return;

    const el = ref.current;
    if (!el) return;

    const doc = el.ownerDocument;
    const view = doc.defaultView;
    if (!view) return;

    lastMeasureRef.current = 0;
    scheduleSync(); // immediate position on show

    const onScroll = () => scheduleSync();
    const onResize = () => scheduleSync();

    doc.addEventListener("scroll", onScroll, true);
    view.addEventListener("resize", onResize);

    let frame = 0;
    const tick = (t: number) => {
      if (t - lastMeasureRef.current >= MEASURE_EVERY_MS) {
        lastMeasureRef.current = t;

        const node = ref.current;
        if (node) {
          const rect = node.getBoundingClientRect();
          const prev = lastRectRef.current;

          const changed =
            !prev ||
            Math.abs(rect.x - prev.x) > 0.5 ||
            Math.abs(rect.y - prev.y) > 0.5 ||
            Math.abs(rect.width - prev.width) > 0.5 ||
            Math.abs(rect.height - prev.height) > 0.5;

          if (changed) {
            lastRectRef.current = rect;
            scheduleSync();
          }
        }
      }

      frame = requestAnimationFrame(tick);
    };

    frame = requestAnimationFrame(tick);

    return () => {
      doc.removeEventListener("scroll", onScroll, true);
      view.removeEventListener("resize", onResize);
      cancelAnimationFrame(frame);
    };
  }, [dragFinished, isSelected, thisIsDragging, scheduleSync]);

  const syncActionsPosition = useCallback(
    (el: HTMLDivElement | null | undefined) => {
      if (el) {
        const view = el.ownerDocument.defaultView;

        if (view) {
          const rect = el.getBoundingClientRect();

          const diffLeft = rect.x;
          const exceedsBoundsLeft = diffLeft < 0;
          const diffTop = rect.y;
          const exceedsBoundsTop = diffTop < 0;

          // Modify position if it spills over frame
          if (exceedsBoundsLeft) {
            el.style.transformOrigin = "left top";
            el.style.left = "0px";
          }

          if (exceedsBoundsTop) {
            el.style.top = "12px";
            if (!exceedsBoundsLeft) {
              el.style.transformOrigin = "right top";
            }
          }
        }
      }
    },
    [zoom]
  );

  const actionBarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    syncActionsPosition(actionBarRef.current);
  }, [actionBarRef.current, syncActionsPosition]);

  useEffect(() => {
    if (userDragAxis) {
      setDragAxis(userDragAxis);
      return;
    }

    if (ref.current) {
      const computedStyle = window.getComputedStyle(ref.current);

      if (
        computedStyle.display === "inline" ||
        computedStyle.display === "inline-block"
      ) {
        setDragAxis("x");

        return;
      }
    }

    setDragAxis(autoDragAxis);
  }, [ref, userDragAxis, autoDragAxis]);

  const selectParentLabel = useMessage("action-selectparent");
  const duplicateLabel = useMessage("action-duplicate");
  const deleteLabel = useMessage("action-delete");

  const parentAction = useMemo(
    () =>
      ctx?.areaId &&
      ctx?.areaId !== "root" && (
        <ActionBar.Action onClick={onSelectParent} label={selectParentLabel}>
          <CornerLeftUp size={16} />
        </ActionBar.Action>
      ),
    [ctx?.areaId, selectParentLabel]
  );

  const nextContextValue = useMemo<DropZoneContext>(
    () => ({
      ...ctx!,
      areaId: id,
      zoneCompound,
      index,
      depth: depth + 1,
      registerLocalZone,
      unregisterLocalZone,
    }),
    [
      ctx,
      id,
      zoneCompound,
      index,
      depth,
      registerLocalZone,
      unregisterLocalZone,
    ]
  );

  const richText = useAppStore((s) =>
    s.currentRichText?.inlineComponentId === id ? s.currentRichText : null
  );

  const hasNormalActions = permissions.duplicate || permissions.delete;

  return (
    <DropZoneProvider value={nextContextValue}>
      {dragFinished &&
        isVisible &&
        createPortal(
          <div
            className={getClassName({
              isSelected,
              isDragging: thisIsDragging,
              hover: hover || indicativeHover,
            })}
            style={{ ...style }}
            data-puck-overlay
          >
            {debug}
            {isLoading && (
              <div className={getClassName("loadingOverlay")}>
                <Loader />
              </div>
            )}
            <div
              className={getClassName("actionsOverlay")}
              style={{
                top: actionsOverlayTop / zoom,
              }}
            >
              <div
                className={getClassName("actions")}
                style={{
                  transform: `scale(${1 / zoom}`,
                  top: actionsTop / zoom,
                  right: 0,
                  paddingLeft: actionsSide,
                  paddingRight: actionsSide,
                }}
                ref={actionBarRef}
              >
                <CustomActionBar
                  parentAction={parentAction}
                  label={DEBUG ? id : label}
                >
                  {richText && (
                    <>
                      <LoadedRichTextMenu
                        editor={richText.editor}
                        field={richText.field}
                        inline
                        readOnly={false}
                      />
                      {hasNormalActions && <ActionBar.Separator />}
                    </>
                  )}

                  {permissions.duplicate && (
                    <ActionBar.Action
                      onClick={onDuplicate}
                      label={duplicateLabel}
                    >
                      <Copy className={getClassName("actionsAction")} />
                    </ActionBar.Action>
                  )}
                  {permissions.delete && (
                    <ActionBar.Action onClick={onDelete} label={deleteLabel}>
                      <Trash className={getClassName("actionsAction")} />
                    </ActionBar.Action>
                  )}
                </CustomActionBar>
              </div>
            </div>
            <div className={getClassName("overlayWrapper")}>
              <CustomOverlay
                componentId={id}
                componentType={componentType}
                hover={hover}
                isSelected={isSelected}
              >
                <div className={getClassName("overlay")}></div>
              </CustomOverlay>
            </div>
          </div>,
          portalEl || document.body
        )}
      {children(refSetter)}
    </DropZoneProvider>
  );
};
